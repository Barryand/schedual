package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.Grade;

import dao.DbService;

public class recordServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public recordServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		DbService dbService = new DbService();
		String record_type = null;
		try{
			record_type = request.getParameter("record_type");
		}catch(Exception ex){
			ex.printStackTrace();
		}
		ResultSet rs = dbService.RecordQuery(record_type);
		List<Grade> recordlist= new ArrayList<Grade>();
		Grade record = null;
		System.out.println("record_type "+record_type);
		try {
			while(rs.next()){
				System.out.println("rs.getRow()"+rs.getRow());
				record = new Grade();
				record.setGrade_name(rs.getString("grade_name"));
				record.setGrade_record(rs.getFloat("grade_record"));
				record.setGrade_worldrecord(rs.getFloat("grade_worldrecord"));
				recordlist.add(record);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.getSession().setAttribute("recordlist", recordlist);
		request.getRequestDispatcher("/record_query.jsp").forward(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
