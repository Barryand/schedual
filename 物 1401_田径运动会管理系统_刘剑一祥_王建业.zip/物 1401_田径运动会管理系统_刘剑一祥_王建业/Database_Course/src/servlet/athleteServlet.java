package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.Athelet;
import biz.Schedule;
import dao.DbService;

public class athleteServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public athleteServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		System.out.println("shit");
		DbService dbService = new DbService();
		System.out.println("kuso");
		if(request.getParameter("athlete_query") != null){
			System.out.println("oh");
			String[] match_types = request.getParameterValues("athlete_query");
			System.out.println("match_types[0]:" + match_types[0]);
			Vector<ResultSet> rss = new Vector<ResultSet>(match_types.length);
			for (int i = 0; i<match_types.length; i++)
		 	{
				rss.addElement(dbService.AthelteQuery(match_types[i]));
		 	}
			List<Athelet> atheletlist= new ArrayList<Athelet>();
			Athelet athelet = null;
			try {
				int capacity = 0;
				capacity = rss.capacity();
				System.out.println("rss.capacity()"+rss.capacity());
				for (int i = 0; i<capacity; i++){
					while(rss.get(i).next()){
						athelet = new Athelet();
						athelet.setAth_name(rss.get(i).getString("ath_name"));
						athelet.setAth_area(rss.get(i).getString("ath_area"));
						athelet.setAth_project(rss.get(i).getString("ath_project"));
						athelet.setAth_grade(rss.get(i).getFloat("ath_grade"));
						athelet.setSchedule_process(rss.get(i).getString("schedule_process"));
						atheletlist.add(athelet);
					}
				}
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("atheletlist.size()"+atheletlist.size());
			request.getSession().setAttribute("atheletlist", atheletlist);
			request.getRequestDispatcher("/athelet_query.jsp").forward(request, response);
		}
		else{
			request.getRequestDispatcher("/failure.jsp").forward(request, response);
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
