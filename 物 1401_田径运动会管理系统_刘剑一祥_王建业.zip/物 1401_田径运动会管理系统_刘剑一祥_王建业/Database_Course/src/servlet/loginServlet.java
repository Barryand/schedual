package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.Users;
import dao.DbService;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String username = null;
		String password = null;
		DbService dbService = new DbService();
		Users user = new Users();
		PrintWriter out = response.getWriter();
		try{
			username = request.getParameter("username");
			password = request.getParameter("password");
		}catch(Exception ex){
			ex.printStackTrace();
		}
		user = dbService.hasUser(username, password);
		if (user.getUsername() == null) {
            System.out.print("�û������벻��ȷ��");
            out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
    		out.println("<HTML>");
    		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
    		out.println("  <BODY>");
    		out.println("username or password is wrong��");
    		out.println("  </BODY>");
    		out.println("</HTML>");
    		out.flush();
    		out.close();
            
        } else {
        	//request.getSession().setAttribute("dbService", dbService);
        	request.getRequestDispatcher("/welcome.jsp").forward(request, response);
        }
	}
}
