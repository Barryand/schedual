package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.Area;
import biz.Grade;
import dao.DbService;

/**
 * Servlet implementation class conditionareaServlet
 */
@WebServlet("/conditionareaServlet")
public class conditionareaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public conditionareaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		DbService dbService = new DbService();
		String area_type = null;
		//
		try{
			area_type = request.getParameter("area_type");
		}catch(Exception ex){
			ex.printStackTrace();
			System.out.println("aaa ");
		}
		System.out.println("bbb ");
		ResultSet rs = dbService.conditionArea(area_type);
		List<Area> arealist= new ArrayList<Area>();
		Area area = null;
		System.out.println("area_type "+area_type);

		try {
			while(rs.next()){
				System.out.println("rs.getRow()"+rs.getRow());
				area = new Area();
				area.setAth_name(rs.getString("ath_name"));
				area.setAth_project(rs.getString("ath_project"));
				area.setAth_grade(rs.getFloat("ath_grade"));
				arealist.add(area);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.getSession().setAttribute("arealist", arealist);
		request.getRequestDispatcher("/areacondition.jsp").forward(request, response);	}

}
