package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.Schedule;
import dao.DbService;

/**
 * Servlet implementation class schedule_displayServlet
 */
@WebServlet("/schedule_displayServlet")
public class schedule_displayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public schedule_displayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		DbService dbService = new DbService();
		ResultSet rs = dbService.ScheduleQuery();
		
		List<Schedule> schedulelist= new ArrayList<Schedule>();
		Schedule schedule = null;
		System.out.println("doGet");
		try {
			while(rs.next()){
				schedule = new Schedule();
				schedule.setSchedule_name(rs.getString("schedule_name"));
				schedule.setSchedule_time(rs.getString("schedule_time"));
				schedule.setSchedule_area(rs.getString("schedule_area"));
				schedule.setSchedule_athlete(rs.getString("schedule_athlete"));
				schedule.setSchedule_process(rs.getString("schedule_process"));
				schedulelist.add(schedule);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.getSession().setAttribute("schedulelist", schedulelist);
		if (request.getParameter("choose").equals("query")){
			request.getRequestDispatcher("/schedule_display.jsp").forward(request, response);
		}else if (request.getParameter("choose").equals("modify")){
			request.getRequestDispatcher("/schedule_modify.jsp").forward(request, response);
		}
		out.println(request.getParameter("choose"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
