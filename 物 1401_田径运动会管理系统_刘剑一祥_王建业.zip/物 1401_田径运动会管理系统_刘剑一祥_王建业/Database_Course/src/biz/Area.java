package biz;

public class Area {
	private String area_name;
	private Float ath_grade;
	private String ath_name;
	private String ath_project;
	public String getArea_name() {
		return area_name;
	}
	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}
	public Float getAth_grade() {
		return ath_grade;
	}
	public void setAth_grade(Float ath_grade) {
		this.ath_grade = ath_grade;
	}
	public String getAth_name() {
		return ath_name;
	}
	public void setAth_name(String ath_name) {
		this.ath_name = ath_name;
	}
	public String getAth_project() {
		return ath_project;
	}
	public void setAth_project(String ath_project) {
		this.ath_project = ath_project;
	}
	
	
}
