package biz;

public class Schedule {
	private String schedule_name;
	private String schedule_time;
	private String schedule_area;
	private String schedule_athlete;
	private String schedule_process;
	
	public String getSchedule_name() {
		return schedule_name;
	}
	public void setSchedule_name(String schedule_name) {
		this.schedule_name = schedule_name;
	}
	public String getSchedule_time() {
		return schedule_time;
	}
	public void setSchedule_time(String schedule_time) {
		this.schedule_time = schedule_time;
	}
	public String getSchedule_area() {
		return schedule_area;
	}
	public void setSchedule_area(String schedule_area) {
		this.schedule_area = schedule_area;
	}
	public String getSchedule_athlete() {
		return schedule_athlete;
	}
	public void setSchedule_athlete(String schedule_athlete) {
		this.schedule_athlete = schedule_athlete;
	}
	public String getSchedule_process() {
		return schedule_process;
	}
	public void setSchedule_process(String schedule_process) {
		this.schedule_process = schedule_process;
	}
	
}
