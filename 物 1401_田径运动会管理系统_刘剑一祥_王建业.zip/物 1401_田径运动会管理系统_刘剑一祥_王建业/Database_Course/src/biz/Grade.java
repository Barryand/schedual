package biz;

public class Grade {
	private Float grade_record;
	private Float grade_worldrecord;
	private String grade_process;
	private String grade_name;
	private String grade_athlete;
	private Float grade_grade;
	public Float getGrade_record() {
		return grade_record;
	}
	public void setGrade_record(Float grade_record) {
		this.grade_record = grade_record;
	}
	public Float getGrade_worldrecord() {
		return grade_worldrecord;
	}
	public void setGrade_worldrecord(Float grade_worldrecord) {
		this.grade_worldrecord = grade_worldrecord;
	}
	public String getGrade_process() {
		return grade_process;
	}
	public void setGrade_process(String grade_process) {
		this.grade_process = grade_process;
	}
	public String getGrade_name() {
		return grade_name;
	}
	public void setGrade_name(String grade_name) {
		this.grade_name = grade_name;
	}
	public String getGrade_athlete() {
		return grade_athlete;
	}
	public void setGrade_athlete(String grade_athlete) {
		this.grade_athlete = grade_athlete;
	}
	public Float getGrade_grade() {
		return grade_grade;
	}
	public void setGrade_grade(Float grade_grade) {
		this.grade_grade = grade_grade;
	}
	

}
