package biz;

public class Athelet {
	private String ath_name;
	private String ath_area;
	private String ath_project;
	private float ath_grade;
	private String schedule_process;
	
	public String getAth_name() {
		return ath_name;
	}
	public void setAth_name(String ath_name) {
		this.ath_name = ath_name;
	}
	public String getAth_area() {
		return ath_area;
	}
	public void setAth_area(String ath_area) {
		this.ath_area = ath_area;
	}
	public String getAth_project() {
		return ath_project;
	}
	public void setAth_project(String ath_project) {
		this.ath_project = ath_project;
	}
	public String getSchedule_process() {
		return schedule_process;
	}
	public void setSchedule_process(String schedule_process) {
		this.schedule_process = schedule_process;
	}
	public float getAth_grade() {
		return ath_grade;
	}
	public void setAth_grade(float ath_grade) {
		this.ath_grade = ath_grade;
	}
	
}
