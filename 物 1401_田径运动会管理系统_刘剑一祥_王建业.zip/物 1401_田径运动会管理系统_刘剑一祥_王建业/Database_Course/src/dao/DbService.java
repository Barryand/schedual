package dao;

import biz.Athelet;
import biz.Schedule;
import biz.Users;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Zhen on 2016/5/5.
 */
public class DbService {

    public Users hasUser(String username, String password) {
        Users user = new Users();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select * from users where username=? and password=?";

        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                user.setPassword(rs.getString("password"));
                user.setUsername(rs.getString("username"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbConnection.closeConnection(rs, ps, connection);
        }

        return user;
    }
    
    public Users hasVistor(String username, String password) {
        Users user = new Users();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select * from vistors where username=? and password=?";
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                user.setPassword(rs.getString("password"));
                user.setUsername(rs.getString("username"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbConnection.closeConnection(rs, ps, connection);
        }
        return user;
    }
    
    public ResultSet ScheduleQuery(){
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select * from schedule";
        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            /*while(rs.next())
            {
            	System.out.println("row number");
            }*/
        } catch (SQLException e) {
            e.printStackTrace();
        } 
		return rs;
    }
    public boolean ScheduleInsert(Schedule schedule)
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        String sql = "insert into schedule values(?,?,?,?,?)";
        try {
        	ps = connection.prepareStatement(sql);
        	if (schedule.getSchedule_name() != ""){
        		ps.setString(1, schedule.getSchedule_name());
        	}else{
        		return false;
        	}
        	if (schedule.getSchedule_athlete() != ""){
        		ps.setString(4, schedule.getSchedule_athlete());
        	}else{
        		return false;
        	}
        	if (schedule.getSchedule_process() != ""){
        		ps.setString(5, schedule.getSchedule_process());
        	}else{
        		return false;
        	}
            ps.setString(2, schedule.getSchedule_time());
            ps.setString(3, schedule.getSchedule_area());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
        	System.out.println("ScheduleInsert error");
            e.printStackTrace();
        }
        return false;
    }
    public boolean ScheduleDelete(Schedule schedule)
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        String sql = "delete from schedule where schedule_name=? " +
        		"and schedule_athlete=? and schedule_process=?";
        try {
        	ps = connection.prepareStatement(sql);
        	if (schedule.getSchedule_name() != ""){
        		ps.setString(1, schedule.getSchedule_name());
        	}else{
        		return false;
        	}
        	if (schedule.getSchedule_athlete() != ""){
        		ps.setString(2, schedule.getSchedule_athlete());
        	}else{
        		return false;
        	}
        	if (schedule.getSchedule_process() != ""){
        		ps.setString(3, schedule.getSchedule_process());
        	}else{
        		return false;
        	}
        	ps.executeUpdate();
        	return true;
        }catch (SQLException e) {
        	System.out.println("ScheduleDelete error");
            e.printStackTrace();
        }
        return false;
    }
    public ResultSet AthelteQuery(String match_type)
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select distinct ath_name,ath_area,ath_project,ath_grade,schedule_process from schedule,athlete " +
        		"where ath_name=schedule_athlete and schedule_process=?";
        try {
        	ps = connection.prepareStatement(sql);
            ps.setString(1, match_type);
            rs = ps.executeQuery();
            /*
            int i = 0;
            System.out.println("match_type: "+match_type);
            while(rs.next())
            {
            	System.out.println("row number"+i);
            	i++;
            }
            */
        }catch (SQLException e) {
            e.printStackTrace();
        } 
    	return rs;
    }
    public ResultSet RecordQuery(String record_type)
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select grade_name,grade_record,grade_worldrecord from grade where grade_name=?";
        try {
        	ps = connection.prepareStatement(sql);
        	ps.setString(1, record_type);
            rs = ps.executeQuery(); 
 
            System.out.println("match_type: "+record_type);
 
        }catch (SQLException e) {
            e.printStackTrace();
        } 
    	return rs;
    }

    public ResultSet Whole_personQuery()
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        if(connection!=null)
        {
        	System.out.println("yeyi");
        }
        
        String sql = "select grade_grade,grade_athlete from grade where grade_name='quanneng'";
 //       		"order by grade_grade ASC";
        try {
        	ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();


        }catch (SQLException e) {
            e.printStackTrace();
        } 
    	return rs;

    }
    
    public ResultSet conditionArea(String match_type)
    {
    	Connection connection = DbConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        System.out.println("RecordQuery223");
        String sql = "select ath_grade,ath_name,ath_project from athlete,area "+
        		"where area_name=ath_area and area_name=?";
        System.out.println("RecordQuery322");
        try {
        	ps = connection.prepareStatement(sql);
            ps.setString(1, match_type);
            System.out.println(match_type);
            rs = ps.executeQuery();
            System.out.println("match_type: "+match_type);

        }catch (SQLException e) {
            e.printStackTrace();
        } 
    	return rs;
    }

}

