use Database_Course_Design;
go

if OBJECT_ID('users','TABLE') IS NOT NULL
	drop table users 
if OBJECT_ID('vistors','TABLE') IS NOT NULL
	drop table vistors 
if OBJECT_ID('athlete','TABLE') IS NOT NULL
	drop table athlete 
if OBJECT_ID('grade','TABLE') IS NOT NULL
	drop table grade 
if OBJECT_ID('schedule','TABLE') IS NOT NULL
	drop table schedule 
if OBJECT_ID('judge','TABLE') IS NOT NULL
	drop table judge 
if OBJECT_ID('project','TABLE') IS NOT NULL
	drop table project 
if OBJECT_ID('area','TABLE') IS NOT NULL
	drop table area 

create table users(
	username varchar(50)not null,
	password varchar(50)not null,
	primary key(username, password));

create table vistors(
	username varchar(50)not null,
	password varchar(50)not null,
	primary key(username, password));
	

CREATE TABLE area (
	area_name VARCHAR(100)  NOT NULL,
	area_num  INT 	NOT NULL,   --INT UNSIGEND
	PRIMARY KEY (area_name)
	);
	

	
CREATE TABLE project (
	project_name VARCHAR(100)  NOT NULL,
	project_type VARCHAR(100)	 NOT NULL,
	PRIMARY KEY (project_name)
	);
CREATE TABLE athlete (
	ath_name VARCHAR(100) NOT NULL,
	ath_area VARCHAR(100) NOT NULL,
	ath_project VARCHAR	(100) NOT NULL,
	ath_grade FLOAT NOT NULL,
	PRIMARY KEY (ath_name,ath_project),
	--FOREIGN	KEY	(ath_area)references area(area_name),
	--FOREIGN	KEY	(ath_project)references project(project_name)
);

CREATE TABLE schedule (
	schedule_name VARCHAR(100) NOT NULL,
	schedule_time VARCHAR	(100) NOT NULL,
	schedule_area VARCHAR(100) NOT NULL,
	schedule_athlete VARCHAR	(100) NOT NULL,
	schedule_process VARCHAR	(100) NOT NULL,
	PRIMARY KEY (schedule_name, schedule_athlete, schedule_process),
	--FOREIGN	KEY	(schedule_area) references area(area_name),
	--FOREIGN	KEY	(schedule_name) references project(project_name)
	);	
	
CREATE TABLE grade (
	grade_process VARCHAR(100) NOT NULL,
	grade_grade FLOAT NOT NULL,
	grade_name VARCHAR(100) NOT NULL,
	grade_athlete VARCHAR	(100) NOT NULL,
	grade_worldrecord FLOAT	 NOT NULL,
	grade_record FLOAT NOT NULL,	
	PRIMARY KEY (grade_process, grade_name, grade_athlete),
	--FOREIGN	KEY	(grade_name) references	project(project_name),
);


CREATE TABLE judge (
	judge_name VARCHAR(100)  NOT NULL,
	judge_process VARCHAR(100)	 NOT NULL,
	judge_project VARCHAR(100)	 NOT NULL,
	PRIMARY KEY (judge_name,judge_process,judge_project),
	--FOREIGN	 KEY(judge_project) references	project(project_name),
	);

insert into 
users (username,password) 
values('Barry', '12345');
insert into 
vistors (username,password) 
values('Eric', '12345');

INSERT	INTO area	
VALUES('江苏','13');

INSERT	INTO area	
VALUES('湖北','12');

INSERT	INTO area	
VALUES('广州','13');

INSERT	INTO area	
VALUES('浙江','11');

INSERT	INTO area	
VALUES('北京','7');

INSERT	INTO area	
VALUES('湖南','12');

INSERT	INTO area	
VALUES('江西','11');

INSERT	INTO area	
VALUES('新疆','9');

INSERT INTO project
VALUES('男子1500米','长跑');

INSERT INTO project
VALUES('男子5000米','长跑');

INSERT INTO project
VALUES('男子10000米','长跑');

INSERT INTO project
VALUES('男子100米','短跑');

INSERT INTO project
VALUES('男子200米','短跑');

INSERT INTO project
VALUES('男子400米','短跑');

INSERT INTO project
VALUES('全能','耐力');

INSERT INTO project
VALUES('男子跳高','爆发');

INSERT INTO project
VALUES('男子跳远','爆发');

INSERT INTO project
VALUES('女子跳高','爆发');

INSERT INTO project
VALUES('女子跳远','爆发');

INSERT INTO schedule
VALUES('男子1500米','2017-5-12 08:40:00','江苏','李苏星','A');
INSERT INTO schedule
VALUES('男子1500米','2017-5-12 09:40:00','浙江','徐嘉文','B');
INSERT INTO schedule
VALUES('男子1500米','2017-5-12 08:40:00','江西','刘剑','semi-final');
INSERT INTO schedule
VALUES('男子1500米','2017-5-12 09:40:00','广州','王沛旭','group');
INSERT INTO schedule
VALUES('男子5000米','2017-5-13 08:40:00','江苏','李苏星','A');
INSERT INTO schedule
VALUES('男子5000米','2017-5-13 09:40:00','浙江','徐嘉文','B');
INSERT INTO schedule
VALUES('男子5000米','2017-5-13 08:40:00','江西','刘剑','semi-final');
INSERT INTO schedule
VALUES('男子5000米','2017-5-13 09:40:00','广州','王沛旭','group');
INSERT INTO schedule
VALUES('全能','2017-5-12 15:40:00','江苏','李苏星','A');
INSERT INTO schedule
VALUES('全能','2017-5-12 16:40:00','浙江','徐嘉文','B');
INSERT INTO schedule
VALUES('男子10000米','2017-5-12 15:40:00','江西','刘剑','semi-final');
INSERT INTO schedule
VALUES('男子10000米','2017-5-12 16:40:00','广州','王沛旭','group');

INSERT	INTO athlete	
VALUES('李苏星','江苏','男子1500米',270.00);
INSERT	INTO athlete	
VALUES('李苏星','江苏','男子5000米',810.2);
INSERT	INTO athlete	
VALUES('李苏星','江苏','全能',1660.3);
INSERT	INTO athlete	
VALUES('徐嘉文','浙江','男子1500米',263.42);
INSERT	INTO athlete	
VALUES('徐嘉文','浙江','男子5000米',812.21);
INSERT	INTO athlete	
VALUES('徐嘉文','浙江','全能',1570.13);
INSERT	INTO athlete	
VALUES('刘剑','江西','男子1500米',266.42);
INSERT	INTO athlete	
VALUES('刘剑','江西','男子5000米',809.21);
INSERT	INTO athlete	
VALUES('刘剑','江西','男子10000米',1652.13);
INSERT	INTO athlete	
VALUES('王沛旭','广州','男子1500米',253.12);
INSERT	INTO athlete	
VALUES('王沛旭','广州','男子5000米',822.11);
INSERT	INTO athlete	
VALUES('王沛旭','广州','男子10000米',1550.33);

select distinct ath_name,ath_area,ath_project,ath_grade 
from schedule,athlete 
where ath_name=schedule_athlete and schedule_process='group';

INSERT INTO grade
VALUES('A',270.00,'男子1500米','李苏星',222.22,253.12);
INSERT INTO grade
VALUES('A',1660.3,'全能','李苏星',1300,1400);
INSERT INTO grade
VALUES('B',1570.13,'全能','徐嘉文',1300,1400);

INSERT INTO judge
VALUES('王建业','A','男子1500米');

INSERT INTO judge
VALUES('王建业','A','男子5000米');

INSERT INTO judge
VALUES('王建业','A','男子10000米');

INSERT INTO judge
VALUES('曹家行','B','男子1500米');

INSERT INTO judge
VALUES('曹家行','B','男子5000米');

INSERT INTO judge
VALUES('曹家行','B','男子10000米');


select grade_grade,grade_athlete 
from grade 
where grade_name = '全能';